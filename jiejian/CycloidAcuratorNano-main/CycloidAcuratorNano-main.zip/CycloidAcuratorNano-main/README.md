# CycloidAcuratorNano

> https://www.bilibili.com/video/BV1iU4y1T7fv
>
> 

电机型号：2204无刷电机

轴承型号：6705x2、MR106x2、MR74x14

![](https://pengzhihui-markdown.oss-cn-shanghai.aliyuncs.com/img/20211127220034.jpg)

